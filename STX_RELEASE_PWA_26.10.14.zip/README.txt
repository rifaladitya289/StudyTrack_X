# StudyTrack X — build 26.10.14

## Isi paket
- `index.html`: aplikasi STX.
- `manifest.json`, ikon, `sw.js`: berkas PWA agar shell aplikasi bisa di-cache untuk dibuka offline setelah pernah dibuka online pada HTTPS (misalnya GitHub Pages).
- `supabase_stx_schema.sql`: rancangan skema server, belum dijalankan pada proyek Supabase.

## Deploy PWA
1. Unggah semua isi folder ini ke root repository GitHub Pages (bukan hanya `index.html`).
2. Aktifkan GitHub Pages pada repository.
3. Buka URL HTTPS, tunggu halaman termuat, lalu buka lagi sekali agar service worker dapat mengambil alih.
4. Gunakan menu browser `Tambahkan ke layar utama`/`Install app`.

## Batasan yang wajib diketahui
- Data pembelajaran dan catatan masih tersimpan di browser/perangkat, bukan tersinkron ke server.
- Skema Supabase disertakan sebagai rancangan, tetapi belum terhubung ke proyek atau diuji di Supabase.
- Peta sekolah tetap terkunci sampai verifikasi server benar-benar diimplementasikan.
- PWA dapat dipasang dari HTTPS; paket ini bukan APK Android native dan tidak dapat langsung diunggah ke Play Store.
- Hash password lokal memperbaiki penyimpanan password baru/akun yang berhasil login di browser dengan Web Crypto, tetapi bukan pengganti autentikasi server.
